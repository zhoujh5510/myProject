#!/bin/bash

easy_install-2.7 bitstring==2.1.1
easy_install-2.7 blist==1.3.4
easy_install-2.7 python-graph-core==1.8.0
easy_install-2.7 pyparsing==2.0.1