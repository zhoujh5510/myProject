#!/bin/bash

cd SCryptoMinisat
./build.sh
cd ..

cd picosat
./build.sh
cd ..

cd dparser
./build.sh
cd ..

