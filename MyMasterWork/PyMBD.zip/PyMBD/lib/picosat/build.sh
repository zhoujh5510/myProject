#!/bin/bash
cd $(dirname -- "$0")
make clean
./configure
make
