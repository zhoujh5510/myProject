#!/bin/bash
cd SCryptoMinisat
make
